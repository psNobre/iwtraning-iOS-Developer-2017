//
//  ViewController.swift
//  SocialMedia
//
//  Created by Aluno05 on 27/01/17.
//  Copyright © 2017 iwtraining. All rights reserved.
//

import UIKit
import Social

class ViewController: UIViewController {

    @IBOutlet weak var lblContent: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }

    @IBAction func shareOnFacebook(_ sender: Any) {
        share(service: SLServiceTypeFacebook)
    }

    @IBAction func shareOnTwitter(_ sender: Any) {
        share(service: SLServiceTypeTwitter)
    }
    
    func share(service: String) {
        
        let text = "Text shared: " + lblContent.text!
        let url = URL(string: "https://developer.apple.com")
        let img = UIImage(named: "Apple-logo")
        
        
        let socialView = SLComposeViewController(forServiceType: service)
        socialView?.setInitialText(text)
        socialView?.add(url!)
        socialView?.add(img!)
        
        socialView?.completionHandler = { (result: SLComposeViewControllerResult) -> Void in
        
            switch result {
            case .cancelled:
                print("Cancelado!")
            case .done:
                print("Compartilhado!")
            }
        
        }
        
        self.present(socialView!, animated: true, completion: nil)
        
    }
    
}

