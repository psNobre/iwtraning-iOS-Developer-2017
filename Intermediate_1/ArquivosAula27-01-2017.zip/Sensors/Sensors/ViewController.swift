//
//  ViewController.swift
//  Sensors
//
//  Created by Aluno05 on 27/01/17.
//  Copyright © 2017 iwtraining. All rights reserved.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {
    
    @IBOutlet weak var lblAceX: UILabel!
    @IBOutlet weak var lblAceY: UILabel!
    @IBOutlet weak var lblAceZ: UILabel!
    
    @IBOutlet weak var lblGiroX: UILabel!
    @IBOutlet weak var lblGiroY: UILabel!
    @IBOutlet weak var lblGiroZ: UILabel!
    
    @IBOutlet weak var lblMagX: UILabel!
    @IBOutlet weak var lblMagY: UILabel!
    @IBOutlet weak var lblMagZ: UILabel!
    
    @IBOutlet weak var sliderAceX: UISlider!
    @IBOutlet weak var sliderAceY: UISlider!
    @IBOutlet weak var sliderAceZ: UISlider!
    
    @IBOutlet weak var sliderGyroX: UISlider!
    @IBOutlet weak var sliderGyroY: UISlider!
    @IBOutlet weak var sliderGyroZ: UISlider!
    
    @IBOutlet weak var sliderMagX: UISlider!
    @IBOutlet weak var sliderMagY: UISlider!
    @IBOutlet weak var sliderMagZ: UISlider!
    
    // Sensores!
    var mm: CMMotionManager!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mm = CMMotionManager()
        // Gerenciador para celular não travar
        let queue = OperationQueue()
        
        if mm.isAccelerometerAvailable {
            
            mm.accelerometerUpdateInterval = 0.1
            
            mm.startAccelerometerUpdates(to: queue, withHandler: { (accelerometerData :CMAccelerometerData?, error: Error?) in
                
                DispatchQueue.main.async {
                    
                    if error == nil {
                        
                        let acex =  accelerometerData?.acceleration.x
                        let acey =  accelerometerData?.acceleration.y
                        let acez =  accelerometerData?.acceleration.z
                        
                        self.lblAceX.text = "\(acex!)"
                        self.lblAceY.text = "\(acey!)"
                        self.lblAceZ.text = "\(acez!)"
                        
                        self.sliderAceX.value = Float(acex!)
                        self.sliderAceY.value = Float(acey!)
                        self.sliderAceZ.value = Float(acez!)
                        
                    } else {
                        
                        print("Erro: \(error?.localizedDescription))")
                    }
                }
                
            })
        } else {
            print("Acelerômetro não disponível!")
        }
        
        if mm.isGyroAvailable {
            
            mm.gyroUpdateInterval = 0.1
            
            mm.startGyroUpdates(to: queue, withHandler: { (gyroData :CMGyroData?, err:Error?) in
                
                DispatchQueue.main.async {
                    
                    if err == nil {
                        
                        self.lblGiroX.text = "\(gyroData!.rotationRate.x)"
                        self.lblGiroY.text = "\(gyroData!.rotationRate.y)"
                        self.lblGiroZ.text = "\(gyroData!.rotationRate.z)"
                        
                        self.sliderGyroX.value = Float(gyroData!.rotationRate.x)
                        self.sliderGyroY.value = Float(gyroData!.rotationRate.y)
                        self.sliderGyroZ.value = Float(gyroData!.rotationRate.z)
                        
                    } else {
                        print("\(err?.localizedDescription)")
                    }
                }
            })
            
        } else {
            print("Indisponível")
        }
        
        if mm.isMagnetometerAvailable {
            
            mm.magnetometerUpdateInterval = 0.1
            
            mm.startMagnetometerUpdates(to: queue, withHandler: { (magData:CMMagnetometerData?, err:Error?) in
                
                DispatchQueue.main.async {
                    
                    if err == nil {
                        
                        self.lblMagX.text = "\(magData!.magneticField.x)"
                        self.lblMagY.text = "\(magData!.magneticField.y)"
                        self.lblMagZ.text = "\(magData!.magneticField.z)"
                        
                        self.sliderMagX.value = Float(magData!.magneticField.x)
                        self.sliderMagY.value = Float(magData!.magneticField.y)
                        self.sliderMagZ.value = Float(magData!.magneticField.z)
                        
                    } else {
                        
                        print("\(err?.localizedDescription)")
                        
                    }
                }
            })
        } else {
            print("Indisponível")
        }
    }
    
}

